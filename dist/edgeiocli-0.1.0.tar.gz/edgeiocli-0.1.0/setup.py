# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['edgeiocli']

package_data = \
{'': ['*'], 'edgeiocli': ['html/*']}

install_requires = \
['PyJWT>=2.3.0,<3.0.0',
 'figlet>=0.0.1,<0.0.2',
 'pyfiglet>=0.8.post1,<0.9',
 'requests>=2.27.1,<3.0.0',
 'tabulate>=0.8.9,<0.9.0',
 'typer>=0.4.0,<0.5.0']

entry_points = \
{'console_scripts': ['edgeiocli = edgeiocli.main:app']}

setup_kwargs = {
    'name': 'edgeiocli',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'danimair9',
    'author_email': 'danimair9@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
