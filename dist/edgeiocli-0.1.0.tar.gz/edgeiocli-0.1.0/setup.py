# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['edgeiocli']

package_data = \
{'': ['*']}

install_requires = \
['PyJWT>=2.3.0,<3.0.0',
 'figlet>=0.0.1,<0.0.2',
 'pyfiglet>=0.8.post1,<0.9',
 'requests>=2.27.1,<3.0.0',
 'tabulate>=0.8.9,<0.9.0',
 'typer>=0.4.0,<0.5.0']

entry_points = \
{'console_scripts': ['edgeiocli = edgeiocli.main:app']}

setup_kwargs = {
    'name': 'edgeiocli',
    'version': '0.1.0',
    'description': 'The first version of the EdgeIO CLI',
    'long_description': None,
    'author': 'Daniel Mair',
    'author_email': 'edgeio.team@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
