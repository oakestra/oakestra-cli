import json

import pyfiglet
import requests
import typer

import edgeiocli.service
from edgeiocli.token_helper import get_token_expiration_date, send_auth_post_request, get_username, delete_token, \
    set_user_id, send_auth_get_request, set_token, valid_ip, is_logged_in

app = typer.Typer()
app.add_typer(edgeiocli.user.app, name="user")
app.add_typer(edgeiocli.service.app, name="service")
app.add_typer(edgeiocli.application.app, name="application")


@app.command()
def login(username: str,
          system_manager_ip: str = typer.Option(..., prompt=True),
          password: str = typer.Option(
              ..., prompt=True, hide_input=True)
          ):
    login_request = {
        'username': username,
        'password': password
    }
    ip = 'http://' + system_manager_ip

    if not valid_ip(ip):
        msg = typer.style("Wrong IP. System Manager is not available", fg=typer.colors.RED, bold=True)
        typer.echo(msg)
        return

    response = requests.post(ip + "/api/auth/login", json=login_request)

    stud_obj = json.loads(response.text)
    set_token(stud_obj)

    if response.status_code == 200:

        res = send_auth_get_request("/api/user/" + username)
        user_obj = json.loads(res.text)
        id_obj = user_obj['_id']
        id = id_obj['$oid']
        set_user_id(id)

        f = pyfiglet.Figlet(font='slant')
        print(f.renderText('EdgeIO CLI !'))
        print(f"Hello {username} welcome to the EdgeIO CLI!")
        time = get_token_expiration_date().strftime("%d/%m/%Y %H:%M")
        print("You are now logged in and can use the cli until your token expires (" + time + ")")
    else:
        print(response.text)


@app.command()
def logout():
    delete_token()
    print("Tokens are deleted, Goodbye")


@app.command()
def change_password(old=typer.Option(..., prompt="Old password: "),
                    new=typer.Option(..., prompt="New Password: ", confirmation_prompt=True),
                    ):
    if is_logged_in():
        obj = {
            'oldPassword': old,
            'newPassword': new
        }

        resp = send_auth_post_request("/api/user/" + get_username(), obj)
        if resp.status_code == 200:
            msg = typer.style("Password changed successfully", fg=typer.colors.GREEN, bold=True)
        else:
            msg = typer.style("Error occurred", fg=typer.colors.RED, bold=True)
            print(resp.text)
        typer.echo(msg)


if __name__ == '__main__':
    app()
